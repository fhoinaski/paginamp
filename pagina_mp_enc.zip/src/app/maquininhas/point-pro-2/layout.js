

export const metadata = {
    title: "Point Pro 2",
    description: "Escolha a maquininha perfeita para o seu negócio",
  };
  
  export default function RootLayout({ children }) {
    return (
      <html lang="pt-br">
        <body
         
        >
          {children}
        </body>
      </html>
    );
  }
  