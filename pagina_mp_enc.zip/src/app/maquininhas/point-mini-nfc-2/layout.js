

export const metadata = {
    title: "Point Mini NFC 2 NFC2",
    description: "Escolha a maquininha perfeita para o seu negócio",
  };
  
  export default function RootLayout({ children }) {
    return (
      <html lang="pt-br">
        <body
         
        >
          <header>
<div>
  
</div>
          </header>
          {children}
        </body>
      </html>
    );
  }
  